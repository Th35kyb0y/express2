import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { restapiURL } from 'src/app/services/restapi-url';
import { orderBy } from 'lodash';
import { CommonService } from 'src/app/services/common.service';
import { Category } from 'src/app/models/category/category';
import { ProductAPIPath } from './product-api-path';
import { Content, ContentType, DiscountType, ProductDetails } from 'src/app/models/product/product';


const initialObj = {
  area: [],
  agent: [],
  type: []
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {
  @ViewChild('productElement', { static: false })
  public productElement: ElementRef | undefined;
  //categories: any[] = [];
  productCats: any[] = [];
  productContents: any[] = [];

  areas: any[] = [];
  agents: any[] = [];
  types: any[] = [];
  areaPivot: any[] = [];
  search: string | null = null;
  filter: any = initialObj;
  isCert = false;
  isWrnt = false;
  isAppArea = false;
  isRatn = false;
  isSpare = false;
  toggleStyle: boolean = true;
  toggleStyle2: boolean = true;
  toggleStyle3: boolean = true;
  toggleStyle4: boolean = true;
  toggleStyle5: boolean = true;
  toggleStyle6: boolean = true;
  toggleStyle7: boolean = true;
  toggleStyle8: boolean = true;
  showLoaderBar: boolean = false;

  stockF = false;
  categoryF: any[] = [];
  categorySecondF: any[] = [];
  categorySpareF: any[] = [];
  certificateF: any[] = [];
  warrantyF: any[] = [];
  appAreaF: any[] = [];
  ratingsF: any[] = [];
  public _categoriesSpareOnly: Category[] = [];
  private _categoriesSecondOnly: Category[] = [];
  private _categoriesThirdOnly: Category[] = [];
  private _categoriesThirdDistinctOnly: Category[] = [];
  private _ProductAppArea: any=[];
  private _ProductRatings: any = [];
  private _ProductCertificate: any=[];
  private _ProductWarranty: any[] = [];
  private _products: any = [];
  public totalCount:any = 0;
  public pageIndex = 1;
  public pageSize = 15;
  public _catId: number = 0;
  public _categoryId: number = 0;
  public _subCatId: number = 0;
  _searchContent:string=''
  public noOfProForInStock = 0;
  public IsLoaderLazy = false;
  public callOneByOne = 0;
  
  private _noProductImage: string = '../../assets/images/ccrm_no_image.png';
  private _productFirstImage: string = '';
  @HostListener('window:scroll') onScroll(e: Event): void {
    this.onScrollLoadProduct(e);
  }
  constructor(private ApiService: ApiService,
     public route: ActivatedRoute, 
     private CommonService: CommonService) { 

      const sub = this.route.queryParams
      .subscribe(params => {
		this._products = [];
        this._categoryId = params['catId'];
        this._catId = Number(this._categoryId);
        this._subCatId = params["subCatId"];
        this._searchContent = params["searchContent"];
      })
      //this.checkSerachParam();
      this.getCategoriesNew(this._catId,0);
	  this.getCategoriesSpare(this._categoryId, false);
      this.getProductAppArea();
      this.getProductNomerOfStock();
      this.getProductRatings();
      this.getProductCertificate();
      this.getProductWarranty();

     }

     onScrollLoadProduct(e:any){
      const nativeElement = this.productElement?.nativeElement;
	  const container = this.productElement?.nativeElement;
	  const atBottom = container.scrollTop + container.clientHeight >= container.scrollHeight;
  
      console.log(Math.round(document.documentElement.scrollTop) + 450 >= nativeElement.scrollHeight);
      if (nativeElement != null && Math.round(document.documentElement.scrollTop) + 450 >= nativeElement.scrollHeight && this._products.length !== this.totalCount && this.callOneByOne == 0) {
        console.log('Imran')
        this.IsLoaderLazy = true;
        this.callOneByOne = 2000;
        this.pageIndex += 1;
        //this.getLazyProducts(this.pageIndex, this.pageSize);
		this.getProducts(Number(this._catId),false);
       
      }
     }

	 private getProducts(categoryId: number,isLoadAllApplicationArea: boolean) {
		this.showLoaderBar =  true;
		// if(this.pageIndex==0){
		//  this.IsLoader = true;
		//  this._products = [];
		// }
		// this.IsLoader = true;
		//  let userName = "";
		//  if (this._permissionService != null) {
		//    userName = this._permissionService.userClaim == null ? "" : this._permissionService.userClaim.UserName;
		//  }
		 let searchString = "";
		 if (this._searchContent != '' && this._searchContent != undefined) {
		   searchString = this._searchContent;
		 }
	 
	 
		 let categoriesSecondOnly =  '';
		 let categoriesThirdDistinctOnly =  '';
		 let categoriesSpareOnly =  '';
		 let appArea =  '';
		 let ratings =  '';
		 let certificateF =  '';
		 let warrantyF =  '';
	 
		  let  _categoriesSpareOnly = this.categorySpareF//this._categoriesSpareOnly.filter((x=>x.isSelected== true))
		 if(_categoriesSpareOnly.length>0){
		   for(let i=0; i<_categoriesSpareOnly.length;i++){
			 //categoriesSpareOnly =  categoriesSpareOnly + _categoriesSpareOnly[i].id+','
			 categoriesSpareOnly =  categoriesSpareOnly + _categoriesSpareOnly[i]+','
		   }
	 
		   this._categoriesThirdOnly.forEach(x => {x.isSelected = false;});
		   this.categoryF.length=0;
	 
		   this.categorySecondF.length = 0;
		   this._categoriesSecondOnly.forEach((x: any) => {x.isSelected = false;});
		   this.appAreaF.length = 0;
		   this._ProductAppArea.forEach((x: any) => {x.isSelected = false;});
		   this.ratingsF.length = 0;
		   this._ProductRatings.forEach((x: any) => {
			 x.isSelected = false;
		   });
		   this.certificateF.length = 0;
		   this._ProductCertificate.forEach((x: any) => { x.isSelected = false;});
	 
		   this.warrantyF.length = 0;
		   this._ProductWarranty.forEach((x: any) => {x.isSelected = false;});
	 
		 }
	 
		
		 let  _categoriesThirdDistinctOnly = this.categoryF//this._categoriesThirdDistinctOnly.filter((x=>x.isSelected== true))
		 if(_categoriesThirdDistinctOnly.length>0){
		   for(let i=0;i< _categoriesThirdDistinctOnly.length;i++){
			 //categoriesThirdDistinctOnly =  categoriesThirdDistinctOnly + _categoriesThirdDistinctOnly[i].id+','
			 categoriesThirdDistinctOnly =  categoriesThirdDistinctOnly + _categoriesThirdDistinctOnly[i]+','
		   }
		 }
		 let  _categoriesSecondOnly = this.categorySecondF//this._categoriesSecondOnly.filter((x=>x.isSelected== true))
		 if(_categoriesSecondOnly.length>0){
		   for(let i=0;i< _categoriesSecondOnly.length;i++){
			 //categoriesThirdDistinctOnly =  categoriesSecondOnly + _categoriesSecondOnly[i].id+','
			 categoriesSecondOnly =  categoriesSecondOnly + _categoriesSecondOnly[i]+','
		   }
		 }
		 let  _appArea = this.appAreaF//this._ProductAppArea.filter((x=>x.isSelected== true))
		 if(_appArea.length>0){
		   for(let i=0;i< _appArea.length;i++){
			 //appArea =  categoriesSecondOnly + _categoriesSecondOnly[i].id+','
			 appArea =  appArea + _appArea[i]+','
		   }
		 }
		 let  _ratings = this.ratingsF//this._ProductRatings.filter((x=>x.isSelected== true))
		 if(_ratings.length>0){
		   for(let i=0;i< _ratings.length;i++){
			 //ratings =  ratings + _ProductRatings[i].id+','
			 ratings =  ratings + _ratings[i]+','
		   }
		 }
		
		 let  _certificateF = this.certificateF//this._ProductCertificate.filter((x=>x.isSelected== true))
		 if(_certificateF.length>0){
		   for(let i=0;i< _certificateF.length;i++){
			 //certificateF =  certificateF + _ProductCertificate[i].id+','
			 certificateF =  certificateF + _certificateF[i]+','
		   }
		 }
		 let  _warrantyF = this.warrantyF//this._ProductWarranty.filter((x=>x.isSelected== true))
		 if(_warrantyF.length>0){
		   for(let i=0;i< _warrantyF.length;i++){
			 //warrantyF =  warrantyF + _warrantyF[i].id+','
			 warrantyF =  warrantyF + _warrantyF[i]+','
		   }
		 }
		
		 categoriesThirdDistinctOnly = categoriesThirdDistinctOnly.replace(/,\s*$/, "");
		 categoriesSecondOnly = categoriesSecondOnly.replace(/,\s*$/, "");
		 categoriesSpareOnly = categoriesSpareOnly.replace(/,\s*$/, "");
		 appArea = appArea.replace(/,\s*$/, "");
		 ratings = ratings.replace(/,\s*$/, "");
		 certificateF = certificateF.replace(/,\s*$/, "");
		 warrantyF = warrantyF.replace(/,\s*$/, "");
	 
	 
		 let params = {
			 userName:'',
			 categoryId:categoryId+'',
			 searchString:searchString,
			 isInStock:this.stockF,
			 categoriesSecondOnly:categoriesSecondOnly,
			 categoriesThirdDistinctOnly:categoriesThirdDistinctOnly,
			 categoriesSpareOnly:categoriesSpareOnly,
			 appArea:appArea,
			 ratings:ratings,
			 productCertificate:certificateF,
			 productWarranty:warrantyF,
			 page:this.pageIndex,
			 size:this.pageSize,
		   }
		   
		   this.ApiService.httpost(params, ProductAPIPath.getProductsByCategoryAndUserNew).subscribe((result:any) => {
			 debugger
			 this.showLoaderBar =  false;
			 let res =  result.data;
			 if(res.length==0){
				this.callOneByOne = 2000;
				this.IsLoaderLazy = false;
			}
			if(res.length>0 && this.pageIndex==0){
				this.setCategories(res[0].categories);
				let data =  {
					data:res[0].applicationArea
				}
				this.setProductAppArea(data);
				let data2 =  {
					data:res[0].ratings
				}
				this.setRatingProduct(data2);
				let data3 =  {
					data:res[0].productCertificate
				}
				this.setProductCertificate(data3);
				let data4 =  {
					data:res[0].productWarranty
				}
				this.setProductWarranty(data4);
			}
			if (res.length>0) {
				res.forEach((item:any) => {
				item.addToCartText = 'Add To Cart'
				item.quantity = 0
				// if (this.cartDetail != null && this.cartDetail.cartItems != null && this.cartDetail.cartItems.length > 0) {
				// 	let checkItem = this.cartDetail.cartItems.filter(x => { return x.productId == item.id });
				// 	if (checkItem != null && checkItem.length > 0) {
				// 	item.addToCartText = "Go to Cart";
				// 	item.quantity = checkItem[0].quantity;
				// 	item.goToCart = true;
				// 	}
				// }
				})
				this._products   = this._products .concat(res);
				//this._products.sort((a, b) => (a.catOrderNo - b.catOrderNo || a.orderNo - b.orderNo));
				if(res.length>0){
				//let totalcount =  res[0].totalCount
				this.totalCount =  res[0].totalCount
				//this.totalCount =  (totalcount||1)//-1//;
				if(this.totalCount==this._products.length){ 
					this.callOneByOne = 2000;
					this.IsLoaderLazy = false;
				}else{
					this.callOneByOne = 0;
					this.IsLoaderLazy = false;
				}
			
				}
				else{
					this.callOneByOne = 2000;
					this.IsLoaderLazy = false;
				}
			
			  //this.totalCount = this._productsLazy.length;
		  
		  }

		   });
		
		 
	   }

	   public getProductFirstImageContent(contents: Content[]): string {
		const images = contents.filter(function (content: Content) {
		  return content.contentTypeId === ContentType.Image && content.isMain == true;
		});
	
		if (images.length > 0) {
		  this._productFirstImage = images[0].link;
		}
		else {
		  this._productFirstImage = this._noProductImage;
		}
	
		return this._productFirstImage;
	  }


	

     private  getProductNomerOfStock() {
  
      
      let Q='&categoryId='+this._categoryId
		this.ApiService.httpgetMaster(Q, ProductAPIPath.getProductNomerOfStock).subscribe((res:any) => {
		  
		   this.noOfProForInStock = res.data;
		});
    }

<<<<<<< .mine=======  checkSerachParam() {
    this.route.queryParams
      .subscribe((params: any) => {
        console.log(params);
        this.products = [];
        this.search = params.search;
>>>>>>> .theirs
    private getProductCertificate() {
      let Q='&categoryId='+this._categoryId
      this.ApiService.httpgetMaster(Q, ProductAPIPath.getProductCertificateNew).subscribe((res:any) => {
        this.setProductCertificate(res.data)
      });
      
    }
    setProductCertificate(res:any){
      this._ProductCertificate = res.data;
      if (res.data) {
        res.data.forEach((element: any) => {
        if (this.certificateF != null) {
          element.isSelected = this.certificateF.filter(item => {
          return item == Number(element.certificateId)
          }).length > 0 ? true : false;
        }
        });
      }
      }

      setProductWarranty(res:any){
        this._ProductWarranty = res.data;
        if (res.data) {
          res.data.forEach((element: any) => {
          if (this.warrantyF != null) {
            element.isSelected = this.warrantyF.filter(item => {
            return item == element.ratingId
            }).length > 0 ? true : false;
          }
          });
        }
        if (this._ProductWarranty.filter((item: any) => { return item.noOfProduct != 0 || item.isSelected == true }).length > 0) {
          this.isWrnt = true;
        } else {
          this.isWrnt = false;
        }
        }
    setRatingProduct(res:any){
	
	
      
      if (res.data) {
        res.data.forEach((element: any) => {
          if (this.ratingsF != null) {
            element.isSelected = this.ratingsF.filter(item => {
              return item == element.ratingId
            }).length > 0 ? true : false;
          }
        });
      }
	  this._ProductRatings = res.data;
  }

  filterCertificate(e: any, id: string) {
    if (e.target.checked) {
      this.certificateF.push(id);
      this._ProductCertificate.filter((item: any) => { return item.certificateId == id }).forEach((x: any) => {
        x.isSelected = true;
      });
    } else {
      this._ProductCertificate.filter((item: any) => { return item.certificateId == id }).forEach((x: any) => {
        x.isSelected = false;
      });
      const index: number = this.certificateF.indexOf(id);
      if (index !== -1) {
        this.certificateF.splice(index, 1);
      }
    }

        // Code by Imran
		this.categorySpareF.length = 0;
		this._categoriesSpareOnly.forEach((x: any) => {
		  x.isSelected = false;
		});
	// End 
	 //this.actionFilterSec = 5;
	 //this.filterProductListForSide(5);
	 this.filterProductList();
  }
    private getProductRatings() {
      
        
      let Q='&categoryId='+this._categoryId
		this.ApiService.httpgetMaster(Q, ProductAPIPath.getProductRatingNew).subscribe((res:any) => {
		  this.setRatingProduct(res);
		});

<<<<<<< .mine    
    }
=======  getArea() {
    this.ApiService.httpgetMaster("", "/AreaMaster/getAll").subscribe(
>>>>>>> .theirs
    private  getProductWarranty() {
  
      let Q='&categoryId='+this._categoryId
      this.ApiService.httpgetMaster(Q, ProductAPIPath.getProductWarrantyNew).subscribe((res:any) => {
        this.setProductWarranty(res)
      });
     
    }

    filterRatings(e: any, id: string) {
      if (e.target.checked) {
        this.ratingsF.push(id);
        this._ProductRatings.filter((item: any) => { return item.ratingId == id }).forEach((x: any) => {
          x.isSelected = true;
        });
      } else {
        this._ProductRatings.filter((item: any) => { return item.ratingId == id }).forEach((x: any) => {
          x.isSelected = false;
        });
        const index: number = this.ratingsF.indexOf(id);
        if (index !== -1) {
          this.ratingsF.splice(index, 1);
        }
      }
  
         // Code by Imran
        //  this.categorySpareF.length = 0;
        //  this._categoriesSpareOnly.forEach((x: any) => {
        //    x.isSelected = false;
        //  });
     // End 
      //this.actionFilterSec = 4;
      //this.filterProductListForSide(4);
      //this.filterProductList();
    }

  ngOnInit(): void {
	window.scrollTo({ top: 0 });
	this.bindLocalStorage();
   // this.getArea();
  }

  private async bindLocalStorage() {
	
    if (localStorage.getItem('filterProduct')) {
      let lStorageData = localStorage.getItem('filterProduct');
      let filterProduct = JSON.parse(lStorageData != null ? lStorageData : "");
      if (filterProduct != "") {
        this.stockF = filterProduct.stockF;
        this.categoryF = filterProduct.categoryF;
        this.categorySecondF = filterProduct.categorySecondF;
        this.certificateF = filterProduct.certificateF;
        this.appAreaF = filterProduct.appAreaF;
        this.ratingsF = filterProduct.ratingsF;
        this.warrantyF = filterProduct.warrantyF;
        this.categorySpareF = filterProduct.categorySpareF;
		
      }
    }
	// Code by Imran
	this.pageIndex=0;
	if(this._subCatId){
		 
		let isClear:boolean= false
		try{
			let lStorageData = localStorage.getItem('filterProduct') ;
			let filterProduct = JSON.parse(lStorageData != null ? lStorageData : "");
			if (filterProduct != ""){
				let _categoryId = filterProduct._categoryId;
				if(this._categoryId!=_categoryId){
					isClear = true
				}
			}else{
				isClear= false
			}
		}catch(e){
			isClear= false
		}
		if(isClear){
			localStorage.removeItem('filterProduct');
			this.stockF = false;
			this.categoryF = [];
			this.categorySecondF = [];
			this.categorySpareF = [];
			this.certificateF = [];
			this.warrantyF = [];
			this.appAreaF = [];
			this.ratingsF = [];
		}
		
		this.getProducts(Number(this._catId),false);
	}
	else{
		this.getProducts(Number(this._catId),false);
	}
	 
  }

<<<<<<< .mine=======  getAreaPivotCount(areaID: any) {
    return this.areaPivot.filter(e => e.areaID === areaID).length;
  }
>>>>>>> .theirs
  get productCertificate(): any[] {
    return this._ProductCertificate;
  }
	get categoriesSecond(): Category[] {
		return this._categoriesSecondOnly;
	}
	get categories(): Category[] {
		return this._categoriesThirdDistinctOnly;
	}
	get productAppArea(): any[] {
		return this._ProductAppArea;
	}
  get productRatings(): any[] {
    
    return this._ProductRatings;
  }
  get categoriesSpare(): Category[] {
    return this._categoriesSpareOnly;
  }
  get productWarranty(): any[] {
    return this._ProductWarranty;
  }
  get products(): ProductDetails[] {
    return this._products;
  }

	setProductAppArea(res:any){
	
		this._ProductAppArea = res.data;
		if (res.data) {
		  res.data.forEach((element: any) => {
			if (this.appAreaF != null) {
			  element.isSelected = this.appAreaF.filter(item => {
				return item == element.applicationAreaId
			  }).length > 0 ? true : false;
			}
		  });
		}
	  }

    
  filterWarranty(e: any, id: string) {
    
    if (e.target.checked) {
      this.warrantyF.push(id);
      this._ProductWarranty.filter((item: any) => { return item.id == id }).forEach((x: any) => {
        x.isSelected = true;
      });
    } else {
      this._ProductWarranty.filter((item: any) => { return item.id == id }).forEach((x: any) => {
        x.isSelected = false;
      });
      const index: number = this.warrantyF.indexOf(id);
      if (index !== -1) {
        this.warrantyF.splice(index, 1);
      }
    }
    // Code by Imran
	this.categorySpareF.length = 0;
	this._categoriesSpareOnly.forEach((x: any) => {
	  x.isSelected = false;
	});
 // End 
 
	 this.filterProductList();
  }
	  filterAppArea(e: any, id: string) {
		if (e.target.checked) {
		  this.appAreaF.push(id);
		  this._ProductAppArea.filter((item: any) => { return item.applicationAreaId == id }).forEach((x: any) => {
			x.isSelected = true;
		  });
		   this.stockF = false;
		} else {
		  this._ProductAppArea.filter((item: any) => { return item.applicationAreaId == id }).forEach((x: any) => {
			x.isSelected = false;
		  });
		  const index: number = this.appAreaF.indexOf(id);
		  if (index !== -1) {
			this.appAreaF.splice(index, 1);
		  }
		}
	
		  // Code by Imran
		  this.categorySpareF.length = 0;
		  this._categoriesSpareOnly.forEach((x: any) => {
			x.isSelected = false;
		  });
	  // End 
   
	   //this.actionFilterSec = 3;
	   //this.filterProductListForSide(3);
	   this.filterProductList();
	  }

  	setCategories(res:any){

    //this._categories = res;
    this._categoriesThirdOnly = [];
    this._categoriesSecondOnly = [];
   
    res.forEach((element:any,index:number) => {
      this._categoriesSecondOnly.push(element);
      if (this.categorySecondF != null) {
      element.isSelected = this.categorySecondF.filter(item => {
        return item == element.id
      }).length > 0 ? true : false;
      }
    
  
      element.children.forEach((elementC:any,index2:number) => {
        this._categoriesThirdOnly.filter(item => item.name == elementC.name).forEach(x => {
          x.noOfProduct = x.noOfProduct + elementC.noOfProduct
          
          });
        this._categoriesThirdOnly.push(elementC);
        if (this.categoryF != null) {
          elementC.isSelected = this.categoryF.filter(item => {
          return item == elementC.id
          }).length > 0 ? true : false;
        }
      });
    });
  
   
   this.getCategoryThirdDistinct();
  
    }

	private getCategoryThirdDistinct() {

		this._categoriesThirdDistinctOnly = [];
		this._categoriesThirdOnly.forEach(element => {
		  let dataEsixt = this._categoriesThirdDistinctOnly.filter(item => { return item.name == element.name });
		  if (dataEsixt.length <= 0) {
			this._categoriesThirdDistinctOnly.push(element)
		  }
		});
		

	  }
<<<<<<< .mine=======  }
>>>>>>> .theirs

	filterCategory(e: any, id: number, name: string) {
	
		if (e.target.checked) {
		  this._categoriesThirdOnly.filter(item => item.name == name).forEach(x => {
			this.categoryF.push(x.id);
			x.isSelected = true;
		  });
	
		} else {
		  this._categoriesThirdOnly.filter(item => item.name == name).forEach(x => {
			x.isSelected = false;
			const index: number = this.categoryF.indexOf(x.id);
			if (index !== -1) {
			  this.categoryF.splice(index, 1);
			}
		  });
	
		}
		 // Code by Imran
		 this.categorySpareF.length = 0;
		 this._categoriesSpareOnly.forEach((x: any) => {
		   x.isSelected = false;
		 });
		 this.stockF =  false;
	 // End 
	  this.filterProductList();
	  }

    filterStock(e: any) {
      if (e.target.checked) {
        this.stockF = true;
      } else {
        this.stockF = false;
      }
      //this.actionFilterSec = 0;
      //this.filterProductListForSide(0);
  
      // Code by Imran
    	this._categoriesThirdOnly.forEach(x => {
         
          x.isSelected = false;
        });
        this.categoryF.length=0;
  
        this.categorySecondF.length = 0;
        this._categoriesSecondOnly.forEach((x: any) => {
          x.isSelected = false;
        });
  
        this.appAreaF.length = 0;
        this._ProductAppArea.forEach((x: any) => {
          x.isSelected = false;
        });
  
        this.ratingsF.length = 0;
        this._ProductRatings.forEach((x: any) => {
          x.isSelected = false;
        });
  
  
        this.certificateF.length = 0;
        this._ProductCertificate.forEach((x: any) => {
          x.isSelected = false;
        });
  
        this.warrantyF.length = 0;
        this._ProductWarranty.forEach((x: any) => {
          x.isSelected = false;
        });
  
  
       // Code by Imran
        this.categorySpareF.length = 0;
        this._categoriesSpareOnly.forEach((x: any) => {
          x.isSelected = false;
        });
    // End 
  // End 
     // this.filterProductList();
	 this.filterProductList();
    }

	filterProductList() {

		this.pageIndex=0;
		this._products =[];
		this.createLocalStorageForFilter();
		this.getProducts(Number(this._catId),false);
	  }

	  private createLocalStorageForFilter() {
		let filterProduct = {
		  stockF: this.stockF, categoryF: this.categoryF, categorySecondF: this.categorySecondF, certificateF: this.certificateF, appAreaF: this.appAreaF,
		  ratingsF: this.ratingsF, warrantyF: this.warrantyF, categorySpareF: this.categorySpareF,
		  _categoryId:this._categoryId
		}
		localStorage.setItem('filterProduct', JSON.stringify(filterProduct));
	  }
    getCategoriesNew(parentId: number,categoryId:number) {
      
      let Q='&parentCategoryId='+parentId+'&catId='+categoryId
      this.ApiService.httpgetMaster(Q, ProductAPIPath.GetCategory).subscribe(
        (response: any) => {

          //this.categories = response.data;
          this.setCategories(response.data);
        },
        (err) => {
        }
      );
    }

	private  getCategoriesSpare(parentId: number, isNextLevel: boolean) {


		let Q='&categoryId='+parentId
		this.ApiService.httpgetMaster(Q, ProductAPIPath.getCategorySpares).subscribe(
		  (response: any) => {
		let res:any = 	response.data;
			this._categoriesSpareOnly = [];
		  res.forEach((element:any,index:number) => {
			this._categoriesSpareOnly.push(element);
			if (this.categorySpareF != null) {
			  element.isSelected = this.categorySpareF.filter(item => {
				return item == element.id
			  }).length > 0 ? true : false;
			}
		   
	
		  });
		  
		  if (this._categoriesSpareOnly.filter((item: any) => { return item.noOfProduct != 0 || item.isSelected == true }).length > 0) {
			this.isSpare = true;
		  } else {
			this.isSpare = false;
		  }
		  
			//this.setCategories(response.data);
		  },
		  (err) => {
		  }
		);

	
		
		
	  }
	private getProductAppArea() {
		let Q='&categoryId='+this._categoryId
		this.ApiService.httpgetMaster(Q, ProductAPIPath.GetProductApplicationArea).subscribe((res:any) => {
		  
		  this.setProductAppArea(res.data);
		});
	  }

	filterCategorySecond(e: any, id: number) {
		if (e.target.checked) {
		  this.categorySecondF.push(id);
		  this._categoriesSecondOnly.filter((item: any) => { return item.id == id }).forEach((x: any) => {
			x.isSelected = true;
		  });
		} else {
		  this._categoriesSecondOnly.filter((item: any) => { return item.id == id }).forEach((x: any) => {
			x.isSelected = false;
		  });
		  const index: number = this.categorySecondF.indexOf(id);
		  if (index !== -1) {
			this.categorySecondF.splice(index, 1);
		  }
		}
	
		  // Code by Imran
		  this.stockF =  false;
		  this.categorySpareF.length = 0;
		  this._categoriesSpareOnly.forEach((x: any) => {
			x.isSelected = false;
		  });
	  // End 
   
	   //this.actionFilterSec = 2;
	   //this.filterProductListForSide(2);
	   this.filterProductList();
	  }

	  filterCategorySpare(e: any, id: number) {
		if (e.target.checked) {
		  this.categorySpareF.push(id);
		  this._categoriesSpareOnly.filter((item: any) => { return item.id == id }).forEach((x: any) => {
			x.isSelected = true;
		  });
		} else {
		  this._categoriesSpareOnly.filter((item: any) => { return item.id == id }).forEach((x: any) => {
			x.isSelected = false;
		  });
		  const index: number = this.categorySpareF.indexOf(id);
		  if (index !== -1) {
			this.categorySpareF.splice(index, 1);
		  }
		}
	
		//this.actionFilterSec = 2;
		//this.filterProductListForSide(2);
	
		// Code by imran
		this._categoriesThirdOnly.forEach(x => {
				
		  x.isSelected = false;
		});
		this.categoryF.length=0;
	
		this.categorySecondF.length = 0;
		this._categoriesSecondOnly.forEach((x: any) => {
		  x.isSelected = false;
		});
	
		this.appAreaF.length = 0;
		this._ProductAppArea.forEach((x: any) => {
		  x.isSelected = false;
		});
	
		this.ratingsF.length = 0;
		this._ProductRatings.forEach((x: any) => {
		  x.isSelected = false;
		});
	
	
		this.certificateF.length = 0;
		this._ProductCertificate.forEach((x: any) => {
		  x.isSelected = false;
		});
	
		this.warrantyF.length = 0;;
		this._ProductWarranty.forEach((x: any) => {
		  x.isSelected = false;
		});
		this.stockF = false;
		// End
	
		this.filterProductList();
	
	 
		
	  }


	  public deleteItemFromCart(product: ProductDetails) {
		// this.IsLoader = true;
		// let checkItem = this.cartDetail.cartItems.filter(x => { return x.productId == product.id });
		// if (checkItem != null && checkItem.length > 0) {
		//   this._cartService.deleteCartItem(checkItem[0].id).subscribe((response) => {
		// 	this.IsLoader = false;
		// 	if (response) {
		// 	  this._cartService.updateHeaderCart();
		// 	}
		//   }, (error) => {
		// 	this.IsLoader = false;
		//   })
		// } else {
		//   this.IsLoader = false;
		// }
	  }

<<<<<<< .mine
=======debugger;
>>>>>>> .theirs	  public addtocart(product: ProductDetails, showMessage = true as boolean) {
		if (product.quantity == 0) {
		  product.quantity = product.quantity + 1;
		}
		// if (product.goToCart == true) {
		//   this._router.navigate(['./MyCart']);
		// } else {
		//   this.IsLoader = true;
		//   this._cartReq.productId = product.id;
		//   this._cartReq.quantity = product.quantity;
		//   this._cartService.addItemToCart(this._cartReq).subscribe((res) => {
		// 	if (res) {
		// 	  this.IsLoader = false;
		// 	  product.addToCartText = "Go to Cart";
		// 	  product.goToCart = true;
		// 	  this._cartService.updateHeaderCart();
			  
		// 	}
		//   },
		// 	error => {
		// 	  this.IsLoader = false;
		// 	  console.log(error);
		// 	});
		// }
	  }

	  public subQuantity(product: ProductDetails,) {
		product.goToCart = false;
		if (product.quantity > 0) {
		  product.quantity = product.quantity - 1;
		}
		if (product.quantity == 0) {
		  product.addToCartText = "Add To Cart";
		  this.deleteItemFromCart(product)
		} else {
		  this.addtocart(product, false);
		}
	  }

<<<<<<< .mine=======  removeFromCat(i: any) {
>>>>>>> .theirs<<<<<<< .mine=======  }
>>>>>>> .theirs
<<<<<<< .mine	  public addQuantity(product: ProductDetails,) {
		product.quantity = product.quantity + 1;
		product.addToCartText = "View Cart";
		product.goToCart = false;
		this.addtocart(product, false);
	  }
=======  inc(i: any) {
    this.products[i].qty = (this.products[i].qty) ? ++this.products[i].qty : 1;
    if (this.products[i].qty >= 0) {
      this.CommonService.addToCat(this.products[i])
    } else {
      this.removeFromCat(i);
    }
  }
>>>>>>> .theirs
<<<<<<< .mine






  clearfilter(redirect=true){
    this.filter = initialObj
    document.querySelectorAll('input[type=checkbox]').forEach((e:any)=>{
      e.checked = false;
    })

    if(redirect){
      this.ApiService.gotoURLWithQuery('/products',{clearFilter:"true"})
=======  dec(i: any) {
    this.products[i].qty = (this.products[i].qty && this.products[i].qty > 1) ? --this.products[i].qty : 0;
    if (this.products[i].qty > 0) {
      this.CommonService.addToCat(this.products[i]);
    } else {
      this.removeFromCat(i);
>>>>>>> .theirs    }
  }

<<<<<<< .mine  checkSerachParam() {
    // this.route.queryParams
    //   .subscribe((params:any) => {
    //     console.log(params);
    //     this.products = [];
    //     this.search = params.search;

    //     if(Object.keys(params).length === 0){
    //       this.getCategories(false);
    //     }

    //     if(params.clearFilter == "true"){
    //       return;
    //     }

    //     if (this.search && this.search.length > 2) {
    //       this.clearfilter(false);
    //       this.getCategories(true);
    //     }
    //     if (this.search == "") {
    //       this.ApiService.gotoURL('/')
    //     }

    //     if(params.area){
    //       this.filter.area = params.area.split(",")
    //       this.getCategories(true);
    //     }
    //   });
=======  addToCart(obj: any) {
    if (!this.CommonService.addToCat(obj)) {
      this.ApiService.gotoURL('/user/checkout')
    }
>>>>>>> .theirs  }

<<<<<<< .mine=======  checkAddToCart(obj: any) {
    if (this.CommonService.checkAddToCart(obj)) {
      return "View Cart";
    }
    return "Add To Cart";
  }
>>>>>>> .theirs}
