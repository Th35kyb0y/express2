

export const ProductAPIPath = {



  GetCategory: '/Categories/GetCategory',
  getCategorySpares: '/Categories/getCategorySpares',
  GetProductApplicationArea: '/Categories/getProductApplicationAreaNew',
  getProductNomerOfStock: '/Product/getProductNomerOfStock',
  getProductRatingNew: '/Product/getProductRatingNew',
  getProductCertificateNew: '/Product/getProductCertificateNew',
  getProductWarrantyNew: '/Product/getProductWarrantyNew',
  getProductsByCategoryAndUserNew: '/Product/getProductsByCategoryAndUserNew',
  

}
