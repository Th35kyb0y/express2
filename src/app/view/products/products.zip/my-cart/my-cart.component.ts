import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Content, ContentType, ProductDetails } from 'src/app/models/product/product';
import { CartService } from 'src/app/services/CartService';

@Component({
  selector: 'app-my-cart',
  templateUrl: './my-cart.component.html',
  styleUrls: ['./my-cart.component.scss']
})
export class MyCartComponent implements OnInit {

  _productFirstImage:any=[];
  public pageList: any[] = [];
  private _noProductImage: string = '../../assets/images/ccrm_no_image.png';
  constructor( private _router: Router,
    public cartService: CartService
    ,) { this.getPages(); }

  ngOnInit(): void {
  
    sessionStorage.removeItem('_orderAddresses');
    sessionStorage.removeItem('_editCart');
    localStorage.removeItem('filterProduct');
  }
 
  public getProductFirstImageContent(contents: Content[]): string {
		const images = contents.filter(function (content: Content) {
		  return content.contentTypeId === ContentType.Image && content.isMain == true;
		});
	
		if (images.length > 0) {
		  this._productFirstImage = images[0].link;
		}
		else {
		  this._productFirstImage = this._noProductImage;
		}
	
		return this._productFirstImage;
	  }
  get cartDetail(): ProductDetails[] {
    return this.cartService.cartProducts;
  }

 
  public deleteItemFromCart(product: ProductDetails) {
    debugger
    this.cartService.removeCart(product);
   
  }

  public addQuantity(product: any) {
    if (product != null) {
      product.quantity = product.quantity + 1;
      product.addToCartText = "View Cart";
      product.goToCart = false;
      this.addToCart(product);
    }
  }
  public subQuantity(product: any) {
    if (product != null) {
      product.goToCart = false;
      if (product.quantity > 0) {
        product.quantity = product.quantity - 1;
      }
      if (product.quantity == 0) {
        product.addToCartText = "Add To Cart";
        this.deleteItemFromCart(product)
      } else {
        this.addToCart(product);
      }
    }
  }

  addToCart(product:ProductDetails): void {
    
    
    this.cartService.addToCart(product, []);
  
}
  public goContinueShopping() {
    this._router.navigate(['./home']);
  }

 
  getPages() {
    this.pageList = [];
    this.pageList.push({pageName:'Home'});
    this.pageList.push({pageName:'My Cart'});
  }
}
