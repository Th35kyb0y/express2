import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductsRoutingModule } from './products-routing.module';
import { ProductsComponent } from '../products/products.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PipeModule } from 'src/app/pipes/PipeModule';
import { ProductsComponentsModule } from 'src/app/components/Products/products-components.module';
import { MyCartComponent } from './my-cart/my-cart.component';


@NgModule({
  declarations: [
    ProductsComponent,
    MyCartComponent
  ],
  imports: [
    CommonModule,
   
    PipeModule,
    FormsModule,RouterModule,
    ProductsRoutingModule,
    ProductsComponentsModule,
  ]
})
export class ProductsModule { }
