

export const ProductDetailsAPIPath = {



  GetCategory: '/Categories/GetCategory',
 
  getProductsByProductId: '/Product/getProductsByProductId',
  getProductWarrantyDelivery: '/Product/getProductWarrantyDelivery',
  getStockInHand: '/Product/getStockInHand',
  

}
