import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { CommonService } from 'src/app/services/common.service';
import { ProductDetailsAPIPath } from './product-details-api-path';
import { ProductWarrantyDelivery } from 'src/app/models/productwarrantydelivery/productwarrantydelivery';
import { Content, ContentType } from 'src/app/models/product/product';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailComponent implements OnInit {

  public carouselItems: any[any] = [];
  public mainItems: any[] = [...this.carouselItems]
  public productWarrantyDelivery = {} as ProductWarrantyDelivery ;

  productImages:any = [];
  productContent:any = {
    VideoLinks:[],
    Brochure:null,
    DataSheet:null,
    Presentation:null,
    Image:[],
    ImageFirst:null,
    TechnicalSpecifications:[],
    ProdcutOverview:[],
    Features:[]
  };
  productContents:any = [];
  products:any = [];
  product:any = null;
  public mainImge = "";
  public _productId: any = 0;
  public _pcatId: any = 0;
  constructor(private ApiService: ApiService, public route: ActivatedRoute,private CommonService:CommonService,
    private _activatedroute: ActivatedRoute,) { 

      const sub = this._activatedroute.queryParams
      .subscribe(params => {
        if(params['prodId']){
          this._productId = atob(params['prodId']);
        }
        if(params['catId']){
          this._pcatId = atob(params['catId']);
        }
       
      
      });

    }

  ngOnInit(): void {

    if(!this._productId){
      //this.getProducts()
    }else{
      this.getProducts(this._productId);
    }
   
  }

  public getProductWarrantyDelivery(productCode: string) {

    let Q='&productCode='+productCode
    this.ApiService.httpgetMaster(Q, ProductDetailsAPIPath.getProductWarrantyDelivery).subscribe(
      (response: any) => {
        let res = response.data;
        this.productWarrantyDelivery = res;
      },
      (err) => {
      }
    );
   
  }
  public getProductStock(productCode: string) {

    let Q='&productCode='+productCode
    this.ApiService.httpgetMaster(Q, ProductDetailsAPIPath.getStockInHand).subscribe(
      (response: any) => {
        let res = response.data;
        this.productWarrantyDelivery = res;
      },
      (err) => {
      }
    );
   
  }


  imageGroup: any;
  imageProd: any;

  private getProducts(productId: number) {

    let Q='&productId='+productId
    this.ApiService.httpgetMaster(Q, ProductDetailsAPIPath.getProductsByProductId).subscribe(
      (response: any) => {
        if(response.data.length>0){
          let res = response.data[0];
          this.product = res;
          this.getProductWarrantyDelivery(this.product.code);
          this.getProductStock(this.product.code);
          this.imageGroup = [];
        let i = 0; this.imageProd = [];
        this.carouselItems = this.product.contents.filter((el: Content) => {
          return el.contentTypeId === ContentType.Image
        }).sort((a: Content, b: Content) => {
          return a.orderNo - b.orderNo;
        });
        if (this.carouselItems != null && this.carouselItems.length > 0) {
          this.mainImge = this.carouselItems[0].link;
        }
        this.mainItems = [...this.carouselItems]
        }
       


      },
      (err) => {
      }
    );
 
    
  }

   activeTab(tabname:any){
    document.querySelectorAll('#pills-tabContent .tab-pane').forEach(e=>{
      e.classList.remove('show','active');
      
    });
    (document.getElementById(tabname)as HTMLElement) .classList.add('show', 'active');
  }
  setImage(imgPath: string) {
    this.mainImge = imgPath;
  }
  public Copy() {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = window.location.href;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }


  // removeFromCat() {
  //   this.CommonService.removeFromCat(this.product);
  // }

  // inc() {
  //   this.product = { ...this.product, qty: (this.product.qty) ? ++this.product.qty : 1 }
  //   if(this.product.qty>=0){
  //     this.CommonService.addToCat(this.product)
  //   }else{
  //     this.removeFromCat();
  //   }
  // }

  // dec() {
  //   this.product = { ...this.product , qty: (this.product.qty && this.product.qty > 1) ? --this.product.qty : 0 }
  //   if(this.product.qty>0){
  //     this.CommonService.addToCat(this.product);
  //   }else{
  //     this.removeFromCat();
  //   }
  // }

  // addToCart(){
  //   if(!this.CommonService.addToCat(this.product)){
  //     this.ApiService.gotoURL('/user/checkout')
  //   }
  // }

  // checkAddToCart(obj:any){
  //   if(this.CommonService.checkAddToCart(obj)){
  //     return "Added";
  //   }
  //   return "Add To Cart";
  // }

  // activeTab(tabname:any){
  //   document.querySelectorAll('#pills-tabContent .tab-pane').forEach(e=>{
  //     e.classList.remove('show','active');
      
  //   });
  //   (document.getElementById(tabname)as HTMLElement) .classList.add('show', 'active');
  // }

  // getProductContents() {
  //   this.ApiService.httpget(`&productId=${this.product.id}`, "/ProductContents/getAll").subscribe(
  //     (response: any) => {
  //       if (this.product) {
  //         this.productContents = response.data.filter((e:any) => e.productId == this.product.id);
  //         this.productContent = {
  //           VideoLinks:this.productContents.filter((e:any)=>e.contentTypeId === 1),
  //           Brochure:this.productContents.find((e:any)=>e.contentTypeId === 2),
  //           DataSheet:this.productContents.find((e:any)=>e.contentTypeId === 3),
  //           Presentation:this.productContents.filter((e:any)=>e.contentTypeId === 4),
  //           Image:this.productContents.filter((e:any)=>e.contentTypeId === 5),
  //           ImageFirst:this.productContents.find((e:any)=>e.contentTypeId === 5),
  //           TechnicalSpecifications:this.productContents.filter((e:any)=>e.contentTypeId === 6),
  //           ProdcutOverview:this.productContents.filter((e:any)=>e.contentTypeId === 7),
  //           Features:this.productContents.filter((e:any)=>e.contentTypeId === 8)
  //         }
  //       }
  //       console.log(this.productContent);
  //     },
  //     (err) => {
  //     }
  //   );
  // }

  // getProducts() {

  //   const productname = this.route.snapshot.paramMap.get('productname');

  //   this.ApiService.httpgetMaster("", "/Product/getAll").subscribe(
  //     (response: any) => {

  //       const pObj = response.data.find((e:any) => ApiService.toSnakeCase(e.name) == productname);
  //       this.product = pObj;
  //       if(!this.product.qty){
  //         this.product.qty = this.CommonService.getQty(this.product.id);;
  //       }

  //       this.getProductContents();
  //     },
  //     (err) => {
  //     }
  //   );
  // }

  // productContentObj(pc:any) {
  //   this.productContent = pc;
  // }

}
